import React from 'react';
import { View, Dimensions, Text, StyleSheet, Image } from 'react-native';
import Swiper from 'react-native-swiper';

const { width } = Dimensions.get('window');

export default class Praise extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      banners: [
        require("../../resource/banners/banner1.jpg"),
        require("../../resource/banners/banner2.jpg"),
        require("../../resource/banners/banner3.jpg"),
        require("../../resource/banners/banner4.jpg"),
        require("../../resource/banners/banner5.jpg"),
        require("../../resource/banners/banner6.jpg")]
    }
  }

  render() {
    return (
      <View style={styles.container}>
        <Swiper height={200} autoplay = {true} showsPagination = {true} 
          dotColor="white" activeDotColor='yellow' horizontal={true}>
          {
            this.state.banners.map((item, index) => {
              return <Image style={styles.praiseBgImg} key={index} source={item} />
            })
          }
        </Swiper>
      </View>
    );
  }

  componentDidMount() {

  }

  getBannerListInfo() {
    fetch('http://www.abc.com/list.json')
      .then((res) => res.json())
      .then((res) => {
        this.setState({
          banners: res.data.banners
        })
        alert(this.state.banners)
      })
      .catch((error)=>{
        alert(error);
    });
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee'
  },
  praiseBgImg: {
    backgroundColor: '#eee',
    width: width,
    height: 200,
    resizeMode: 'stretch'
  },
});
