import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default class Treasure extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View>
          <Text style={styles.context}>this is Treasure</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee',
  },
  context: {
    width: 300,
    height: 136,
    lineHeight: 136,
    fontSize: 36,
    textAlign: 'center',
  }
});
