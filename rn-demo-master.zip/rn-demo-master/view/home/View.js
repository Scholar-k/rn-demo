import React from 'react';
import { View, Dimensions, Text, StyleSheet, TextInput, ScrollView, Image } from 'react-native';

const { width } = Dimensions.get('window');

export default class Home extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      list: [],
      fourlist: [{ name: '扫一扫', picture: 'http://bpic.588ku.com/element_origin_min_pic/18/06/10/9321485fa391db0816951db7dacc07b1.jpg' },
        { name: '付钱', picture: 'http://bpic.588ku.com/element_origin_min_pic/18/06/10/9321485fa391db0816951db7dacc07b1.jpg' },
        { name: '收钱', picture: 'http://bpic.588ku.com/element_origin_min_pic/18/06/10/9321485fa391db0816951db7dacc07b1.jpg' },
        { name: '卡包', picture: 'http://bpic.588ku.com/element_origin_min_pic/18/06/10/9321485fa391db0816951db7dacc07b1.jpg' }],
    };
  }

  render() {
    return (
      <View style={styles.container}>
        <View>
          <View style={styles.homeTop}>
            <TextInput
              style={[styles.search, {top: width * .12}]}
              placeholder="请输入搜索内容"
              underlineColorAndroid="#1873B9"
            />
            <View style={styles.fourFunContainer}>
              {
                this.state.fourlist.map((item, index) => {
                  return  <Text style={styles.fourFun} key={index}>
                            <Image style={styles.fourFunImg} source={{uri: item.picture}} />
                            <Text style={styles.fourFunName}>{item.name}</Text>
                          </Text>
                })
              }
            </View>
          </View>
          <ScrollView>
            {
              this.state.list.map((item, index) => {
                return <Text style={styles.textContent} key={index}>{item}</Text>
              })
            }
          </ScrollView>
        </View>
      </View>
    );
  }

  componentDidMount() {
    this.getListInfo()
  }

  getListInfo() {
    fetch('http://www.abc.com/list.json')
      .then((res) => res.json())
      .then((res) => {
        this.setState({
          list: res.data.list
        })
      })
      .catch((error)=>{
        alert(error);
    });
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eee',
  },
  homeTop: {
    backgroundColor: '#1B82D2',
    width: width,
    height: 200,
  },
  search: {
    position: 'absolute',
    left: 20,
    right: 88,
    height: 40,
    lineHeight: 40,
    paddingLeft: 10,
    backgroundColor: '#1873B9',
    color: '#fff',
    borderRadius: 5,
  },
  textContent: {
    width: width,
    height: 136,
    lineHeight: 136,
    fontSize: 36,
    textAlign: 'center',
  },
  fourFunContainer: {
    width: width,
    flex: 1,
    flexDirection: 'row',
    position: 'absolute',
    top: 160,
  },
  fourFun: {
    width: width / 4,
    // textAlign: 'center',
    // flex: 1,
    // flexDirection: 'column',
    color: '#fff',
  },
  fourFunImg: {
    width: width / 4,
    height: width / 4,
    // float: 'left',
  },
  fourFunName: {
    // width: width / 4,
    // height: width / 4,
  }
});
